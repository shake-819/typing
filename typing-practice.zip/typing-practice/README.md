# タイピング練習(ローマ字入力・変換なし)

寿司打のような、IME変換を挟まずローマ字を直接判定するタイピング練習サイトです。
フレームワーク不使用の素のHTML/CSS/JavaScriptで作られています。

## 機能

- ひらがな1文字ごとに複数のローマ字表記(shi/si、tsu/tu、sha/syaなど)を正解として受け付け
- かな・ローマ字の入力進捗をリアルタイム表示
- 画面上のキーボードで次に押すキーをハイライト、ミス時は赤く点滅
- 難易度別(易しい/ふつう/難しい)のお題
- キーごとのミス率を記録し、苦手なキーを可視化(localStorageで永続化)
- ミス数・正確率・1秒あたりの打鍵数(打/秒)を計測

## ファイル構成

```
typing-practice/
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── kana-table.js      # かな→ローマ字パターンの対応表
│   ├── sentences.js       # 難易度別のお題データ
│   ├── typing-engine.js   # 入力判定エンジン(かなの分解・照合)
│   └── keyboard.js        # オンスクリーンキーボードの描画
│   └── app.js             # 画面制御・統計・永続化
└── README.md
```

## ローカルで動かす

ビルド不要です。`index.html` をブラウザで直接開くだけで動作します。

```bash
open index.html   # macOS
# または VS Code の Live Server 拡張などを使う
```

## GitHubにアップロードする手順

1. GitHub上で新しいリポジトリを作成する(例: `typing-practice`)
2. このフォルダの中身をそのリポジトリにコピーする
3. ターミナルで以下を実行

```bash
cd typing-practice
git init
git add .
git commit -m "初回コミット: タイピング練習サイト"
git branch -M main
git remote add origin https://github.com/自分のユーザー名/typing-practice.git
git push -u origin main
```

## GitHub Pagesで公開する

1. リポジトリの `Settings` → `Pages` を開く
2. `Source` を `Deploy from a branch` にし、ブランチを `main` / フォルダを `/ (root)` に設定
3. 数分後に `https://自分のユーザー名.github.io/typing-practice/` で公開される

## 今後拡張しやすいポイント

- `js/sentences.js` にお題を追加するだけで、難易度ごとの出題を増やせます
- `js/kana-table.js` に未対応のローマ字表記(ぁぃぅぇぉ など)を追加できます
- 苦手キーの分析は `js/app.js` の `renderWeakKeys` を拡張すると、グラフ化や期間別の集計にも発展できます
